<template>
    <div class="container test">
        <h1 id="welcome">Welcome to Crack Engineering. </h1>
    </div>
</template>
<script>
   
    export default {
        
    }
</script>

<style scoped>

#welcome{
    position: relative;
    margin-top: 40px;
    text-align: center;
    font-family: "Amatic SC";
    font-size: 55px;
    font-style: normal;
    font-variant: small-caps;
    font-weight: 1000;
    line-height: 55px;
}
.test{
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    top: 50%;
}

</style>


